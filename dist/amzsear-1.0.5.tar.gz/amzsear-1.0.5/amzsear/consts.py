SITE_URL = 'https://www.amazon.com'
BASE_URL = '%s/s/ref=sr_qz_back?sf=qz&keywords=%s&ie=UTF8&tag=alhsabc-20&unfiltered=1&page=%s' % (SITE_URL,'%s','%s')
OUT_URL_TAG = '&tag=alhsabc-20'
OUT_URL_REF = '/ref=as_li_tl?tag=alhsabc-20'
URL_HEADERS = {'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}
DEFAULT_PRICE_TEXT = "Base price"
MAX_COL_SIZE = 80
