try:
    from amzsear.core.AmzSear import AmzSear
except ImportError:
    from .amzsear.core.AmzSear import AmzSear
